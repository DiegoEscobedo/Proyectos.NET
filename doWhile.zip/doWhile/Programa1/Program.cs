﻿using System;

namespace doWhile
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int numero1 = 2;
            int numero2 = 6;
            int numero3 = 9;
            int var0;
            var0 = numero1 + numero2 + numero3;
            Console.WriteLine("La suma de las variables es:" + " " + var0);
        }
    }
}