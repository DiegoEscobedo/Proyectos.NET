﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace CalculadoraIMC.vistas
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ventanaCalcular : ContentPage
    {
        double peso;
        double estatura;
        double IMC;

        public ventanaCalcular()
        {
            InitializeComponent();
        }

        private void CalcularIMC()
        {
            peso = Convert.ToDouble(txtPeso.Text);
            estatura = Convert.ToDouble(txtEstatura.Text);
            IMC = peso / (Math.Pow(estatura, 2));
            lblResultado.Text = IMC.ToString();
            calcularEstado(IMC);
        }

        private void calcularEstado(double resultadoIMC){
            if(resultadoIMC <= 18.50)
            {
                lblEstado.Text = "Peso bajo";
            }
            else if(resultadoIMC <= 24.90)
            {
                lblEstado.Text = "Peso normal";
            }
            else if (resultadoIMC <= 29.90)
            {
                lblEstado.Text = "Pre-obesidad";
            }
            else if (resultadoIMC <= 34.90)
            {
                lblEstado.Text = "Obesidad clase 1";
            }
            else if (resultadoIMC <= 39.90)
            {
                lblEstado.Text = "Obesidad clase 2";
            }
            else
            {
                lblEstado.Text = "Obesidad clase 3 (Estas jodido ya)";
            }
        }

        private void Validar()
        {
            if (!string.IsNullOrEmpty(txtPeso.Text) ||
               !string.IsNullOrEmpty(txtEstatura.Text))
            {
                CalcularIMC();
            }
            else
            {
                DisplayAlert("Error",
                    "Ingresa los valores faltantes", "OK");
            }
        }

        private void btnCalcular_Clicked(object sender, EventArgs e)
        {
            Validar();
        }

        private void btnRegresar_Clicked(object sender, EventArgs e)
        {
            Navigation.PopAsync();
        }

    }
}